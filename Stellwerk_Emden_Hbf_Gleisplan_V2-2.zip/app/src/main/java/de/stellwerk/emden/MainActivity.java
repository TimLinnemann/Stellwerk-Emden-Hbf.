package de.stellwerk.emden;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.RectF;

public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
  setContentView(new Board());
 }
 class Board extends View {
  Paint p=new Paint(3);
  final int dark=0xff222222, gray=0xff9d9d9d, white=0xfff2f2f2, red=0xffd52020, green=0xff27b64c;
  float zoom=1f, panX=0, panY=0, downX,downY,oldDist;
  boolean moving=false, route=false, train=false;
  int selected=-1, switchIndex=0;
  boolean[] switches=new boolean[12];
  Board(){super(MainActivity.this);}
  void box(Canvas c,float x,float y,float w,float h,int color){p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawRect(x,y,x+w,y+h,p);}
  void line(Canvas c,float x,float y,float x2,float y2,int color,float width){p.setStyle(Paint.Style.STROKE);p.setColor(color);p.setStrokeWidth(width);c.drawLine(x,y,x2,y2,p);p.setStyle(Paint.Style.FILL);}
  void label(Canvas c,String s,float x,float y,int size,int color){p.setColor(color);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(size);c.drawText(s,x,y,p);}
  void button(Canvas c,String s,int x,int y,int w,int color){box(c,x,y,w,45,color);label(c,s,x+12,y+30,18,white);}
  void track(Canvas c,int y,int n){
   line(c,40,y,1560,y,dark,7);
   for(int x=80;x<1560;x+=145){box(c,x,y-10,42,20,white);label(c,""+(n*10+x/145),x+5,y+5,10,dark);}
   for(int x=250;x<1450;x+=290){box(c,x,y-15,8,30,0xff333333);box(c,x+12,y-9,10,18,route?green:red);}
   label(c,"Gleis "+n,20,y-18,15,dark);
  }
  @Override protected void onDraw(Canvas raw){
   super.onDraw(raw);
   float sx=getWidth()/1600f, sy=getHeight()/900f;
   raw.save();raw.scale(sx,sy);
   box(raw,0,0,1600,900,0xffd0d4d8);
   box(raw,0,0,1600,42,0xffeeeeee);label(raw,"Simulation    Stellwerk    Bearbeiten    Züge    Streckenanschluss    Information",25,28,18,dark);
   raw.save();raw.clipRect(15,55,1585,590);
   raw.translate(panX,panY);raw.scale(zoom,zoom);
   box(raw,20,60,1560,525,gray);
   for(int x=20;x<=1580;x+=30)line(raw,x,60,x,585,0xff888888,1);
   for(int y=60;y<=585;y+=30)line(raw,20,y,1580,y,0xff888888,1);
   String[] colors={"#444444","#a88c18","#a70000","#174d9c","#188c34","#b00000","#2249a0"};
   for(int i=0;i<7;i++){
    int x=85+i*195;box(raw,x,78,125,48,Color.parseColor(colors[i]));
    label(raw,i%2==0?"SIGNAL":"WEICHE",x+10,98,12,white);
    for(int j=0;j<4;j++)box(raw,x+12+j*26,108,12,9,j%2==0?green:white);
   }
   int[] ys={245,285,325,365,405,445,485,525};
   for(int i=0;i<ys.length;i++)track(raw,ys[i],i+1);
   for(int i=0;i<12;i++){
    int x=155+i*105,y=ys[i%8];
    int targetY=ys[(i+1)%8];
    line(raw,x,y,x+55,targetY,dark,6);
    box(raw,x+8,y-6,13,12,switches[i]?green:0xffffd54f);
    label(raw,"W"+(i+1),x,y-18,13,dark);
   }
   if(route){line(raw,200,325,1350,325,0xfff2d600,5);label(raw,"FAHRSTRASSE AKTIV",650,310,19,0xff2a681e);}
   if(train){box(raw,740,315,100,20,0xff175c9a);label(raw,"RE 1423",744,310,15,dark);}
   label(raw,"Emden Hbf",730,570,18,dark);
   raw.restore();
   box(raw,18,605,455,272,0xffb1b1b1);
   label(raw,"Stellwerksbedienung",30,635,22,dark);
   button(raw,"START",30,658,132,0xff245b88);button(raw,"ZIEL",175,658,130,0xff245b88);button(raw,"RESET",320,658,138,0xff7b3333);
   button(raw,"WEICHE",30,718,132,0xff3d6544);button(raw,"ZUG",175,718,130,0xff3d6544);button(raw,"FAHRSTR.",320,718,138,0xff3d6544);
   label(raw,"Weiche W"+(switchIndex+1)+"  |  "+(route?"Fahrstraße gestellt":"Keine Fahrstraße"),30,812,18,dark);
   box(raw,485,605,500,272,white);label(raw,"Zugübersicht",500,638,22,dark);
   label(raw,train?"RE 1423     Gleis 3     Unterwegs":"Keine Züge im Gleisbild",500,683,19,dark);
   box(raw,995,605,585,272,0xffeeeeee);label(raw,"Aufträge / Meldungen",1010,638,22,dark);
   label(raw,"Emden Hbf  |  Demonstrationsstellwerk",1010,688,18,dark);
   label(raw,"Zwei Finger: Zoom  |  Ein Finger: Verschieben",1010,726,17,dark);
   label(raw,"Tippen auf Gleisbild: Weiche auswählen",1010,761,17,dark);
   raw.restore();
  }
  @Override public boolean onTouchEvent(MotionEvent e){
   float x=e.getX()*1600/getWidth(),y=e.getY()*900/getHeight();
   if(e.getPointerCount()>1){
    float dx=e.getX(0)-e.getX(1),dy=e.getY(0)-e.getY(1),d=(float)Math.hypot(dx,dy);
    if(e.getActionMasked()==MotionEvent.ACTION_POINTER_DOWN)oldDist=d;
    else if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&oldDist>0){zoom=Math.max(0.7f,Math.min(2.8f,zoom*d/oldDist));oldDist=d;invalidate();}
    return true;
   }
   if(e.getActionMasked()==MotionEvent.ACTION_DOWN){downX=x;downY=y;moving=false;return true;}
   if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&downY<590){
    if(Math.abs(x-downX)+Math.abs(y-downY)>5)moving=true;
    panX=Math.max(-1100,Math.min(300,panX+x-downX));panY=Math.max(-400,Math.min(200,panY+y-downY));
    downX=x;downY=y;invalidate();return true;
   }
   if(e.getActionMasked()==MotionEvent.ACTION_UP){
    if(y>658&&y<770){
     int col=x<165?0:x<315?1:2;
     if(y<711){if(col==0)selected=0;else if(col==1){if(selected==0)route=true;}else {route=false;train=false;selected=-1;}}
     else {if(col==0&&!route){switches[switchIndex]=!switches[switchIndex];switchIndex=(switchIndex+1)%12;}else if(col==1){train=!train;if(train)route=false;}else if(col==2)route=!route;}
    }else if(y>60&&y<590&&!moving){
     float bx=(x-panX)/zoom;
     switchIndex=Math.max(0,Math.min(11,(int)((bx-155)/105)));
    }
    invalidate();return true;
   }
   return true;
  }
 }
}
