# Stellwerk Emden Hbf – Android-Prototyp 0.1

Ein **vereinfachtes, nicht historisch authentisches** Gleisbildstellpult, inspiriert von Bundesbahn-Stellwerken. Offline, Querformat, mit Knöpfen, Weiche, Gleisbelegung, Fahrstraße und synthetischem Tastenton. Kein reales Stellwerk und keine sicherungstechnisch geprüfte Simulation.

## Öffnen
1. Ordner in Android Studio öffnen.
2. Gradle-Synchronisierung durchführen (Android SDK 35 / AGP 8.7.3; zum Bauen können SDK und Gradle-Downloads nötig sein).
3. App auf einem Android-Gerät starten oder über Build > Build APK(s) eine APK erzeugen.

## Bedienung
START, dann ZIEL: Fahrstraße über Gleis 2 (nur bei freiem Gleis). WEICHE: Lage ändern, solange keine Fahrstraße aktiv ist. ZUG: Gleisbelegung umschalten; eine Belegung löst die Fahrstraße auf. RESET: zurücksetzen. TON: Töne ein/aus.

**Grenzen:** Der gezeichnete Plan ist frei erfunden und bildet nicht die tatsächlichen Anlagen von Emden Hbf ab. Die Fahrstraßenlogik ist nur ein erster Demonstrator, nicht betriebssicher oder vorbildgetreu.

## APK ohne PC über GitHub Actions bauen
1. Projektdateien in ein GitHub-Repository hochladen (einschließlich `.github/workflows/android-apk.yml`).
2. Auf GitHub unter Actions den Workflow **Android APK erstellen** auswählen und **Run workflow** drücken.
3. Nach erfolgreichem Build unter **Artifacts** `Stellwerk-Emden-APK` herunterladen, ZIP entpacken und `app-debug.apk` auf Android installieren.

Hinweis: Der Build wurde hier nicht ausgeführt; eine APK ist noch nicht enthalten. Dies ist eine vereinfachte Demo und kein historisch korrekter Gleisplan.
