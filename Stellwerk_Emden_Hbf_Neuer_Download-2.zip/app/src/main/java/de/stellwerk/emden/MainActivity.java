package de.stellwerk.emden;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.media.ToneGenerator;
import android.media.AudioManager;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512); setContentView(new Panel()); }
    class Panel extends View {
        Paint p = new Paint(3);
        int selected = -1; boolean route = false, occupied = false, turnout = false, sound = true;
        ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 45);
        Panel(){ super(MainActivity.this); }
        void line(Canvas c,float x,float y,float xx,float yy,int color,float sw){p.setColor(color);p.setStrokeWidth(sw);c.drawLine(x,y,xx,yy,p);}
        void rect(Canvas c,float x,float y,float xx,float yy,int color){p.setColor(color);c.drawRect(x,y,xx,yy,p);}
        void txt(Canvas c,String s,float x,float y,int size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("monospace",Typeface.BOLD));c.drawText(s,x,y,p);}
        void btn(Canvas c,String s,int x,int y,int color){p.setColor(color);c.drawCircle(x,y,22,p);p.setColor(Color.DKGRAY);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawCircle(x,y,22,p);p.setStyle(Paint.Style.FILL);txt(c,s,x-22,y+43,14,0xffe8e5d4);}
        @Override protected void onDraw(Canvas raw){super.onDraw(raw); Canvas c=raw; c.save();c.scale(getWidth()/1000f,getHeight()/560f);
            c.drawColor(0xff222a29);rect(c,15,15,985,545,0xff526458);rect(c,30,65,970,415,0xff6b806f);
            txt(c,"STELLWERK EMDEN HBF",38,43,25,0xfff4e5c6);txt(c,"BUNDESBAHN · SPURPLAN · DEMO",625,42,15,0xfff4e5c6);
            for(int x=45;x<960;x+=35)for(int y=78;y<408;y+=35){p.setColor(0xff617663);p.setStrokeWidth(1);c.drawRect(x,y,x+35,y+35,p);}
            int white=0xffe5e5d5,red=0xffe33b34,yellow=0xfff5e98c;
            txt(c,"RICHTUNG LEER",45,104,15,white);txt(c,"RICHTUNG NORDDEICH",750,104,15,white);
            for(int i=0;i<3;i++){int y=165+i*85;line(c,110,y,880,y,(occupied&&i==1)?red:(route&&i==1)?yellow:white,7);txt(c,"GLEIS "+(i+1),470,y-17,15,white);}
            line(c,130,250,250,165,white,6);line(c,130,250,250,335,white,6);
            line(c,740,165,850,250,white,6);line(c,740,335,850,250,white,6);
            if(turnout)line(c,130,250,250,335,yellow,8);else line(c,130,250,250,165,yellow,8);
            for(int i=0;i<3;i++){int y=165+i*85;rect(c,100,y-18,116,y+18,(route&&i==1)?0xff45e65a:red);rect(c,878,y-18,894,y+18,(route&&i==1)?0xff45e65a:red);}
            txt(c,"FAHRSTRASSE",55,450,16,white);btn(c,"START",125,488,selected==0?yellow:0xffd2d0c0);btn(c,"ZIEL",230,488,selected==1?yellow:0xffd2d0c0);
            txt(c,"BEDIENUNG",335,450,16,white);btn(c,"WEICHE",385,488,0xffd2d0c0);btn(c,"ZUG",495,488,red);btn(c,"RESET",605,488,0xffd2d0c0);btn(c,"TON",715,488,sound?0xff6fe779:0xff777777);
            txt(c,route?"FAHRSTRASSE GLEIS 2 FESTGELEGT":"START UND ZIEL DRUECKEN",38,535,16,route?yellow:white);
            c.restore(); }
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX()*1000/getWidth(),y=e.getY()*560/getHeight();if(y>460&&y<530){if(x<180){selected=0;}else if(x<280){if(selected==0&&!occupied){route=true;}selected=1;}else if(x<440){if(!route)turnout=!turnout;}else if(x<550){occupied=!occupied;if(occupied)route=false;}else if(x<655){route=false;occupied=false;selected=-1;}else if(x<760){sound=!sound;}if(sound)tone.startTone(ToneGenerator.TONE_PROP_BEEP,80);invalidate();}return true;}
    }
}
